--- ecommerce_ai_agents/billing/billing_manager.py (原始)


+++ ecommerce_ai_agents/billing/billing_manager.py (修改后)
"""
Billing Manager - Central orchestrator for all billing operations

Provides unified interface for:
- Subscription management
- Usage tracking integration
- Invoice generation
- Payment processing hooks
- Billing analytics
"""

from typing import Dict, List, Optional, Any
from datetime import datetime, date
import json

from .pricing_config import PricingConfig, SubscriptionPlan
from .usage_tracker import UsageTracker
from .invoice_generator import InvoiceGenerator, Invoice


class BillingManager:
    """
    Central billing manager for the E-commerce AI Agents platform

    Features:
    - User subscription management
    - Real-time usage tracking
    - Automatic invoice generation
    - Cost estimation
    - Billing analytics and reporting
    - Payment processing integration hooks
    """

    def __init__(
        self,
        pricing_config: PricingConfig = None,
        default_tax_rate: float = 0.0,
        default_currency: str = "USD"
    ):
        self.pricing_config = pricing_config or PricingConfig()
        self.usage_tracker = UsageTracker()
        self.invoice_generator = InvoiceGenerator(
            usage_tracker=self.usage_tracker,
            pricing_config=self.pricing_config,
            default_tax_rate=default_tax_rate,
            default_currency=default_currency
        )

        # User subscriptions: user_id -> subscription info
        self._subscriptions: Dict[str, Dict] = {}

        # Payment method storage (integration point)
        self._payment_methods: Dict[str, Dict] = {}

    # ==================== Subscription Management ====================

    def subscribe_user(
        self,
        user_id: str,
        plan_id: str,
        start_date: Optional[date] = None,
        auto_renew: bool = True,
        metadata: Optional[Dict] = None
    ) -> Dict:
        """
        Subscribe a user to a plan

        Args:
            user_id: User identifier
            plan_id: Subscription plan ID
            start_date: Subscription start date (defaults to today)
            auto_renew: Whether to auto-renew
            metadata: Additional subscription metadata

        Returns:
            Subscription confirmation dict
        """
        plan = self.pricing_config.get_subscription_plan(plan_id)
        if not plan:
            raise ValueError(f"Invalid plan ID: {plan_id}")

        if start_date is None:
            start_date = date.today()

        # Calculate next billing date
        if start_date.month == 12:
            next_billing_date = date(start_date.year + 1, 1, start_date.day)
        else:
            try:
                next_billing_date = date(start_date.year, start_date.month + 1, start_date.day)
            except ValueError:
                # Handle month-end edge cases
                next_billing_date = date(start_date.year, start_date.month + 1, 1) - timedelta(days=1)

        subscription = {
            "user_id": user_id,
            "plan_id": plan_id,
            "plan_name": plan.plan_name,
            "monthly_fee": plan.monthly_fee,
            "included_token_credits": plan.included_token_credits,
            "included_api_calls": plan.included_api_calls,
            "start_date": start_date,
            "next_billing_date": next_billing_date,
            "auto_renew": auto_renew,
            "status": "active",
            "metadata": metadata or {},
            "created_at": datetime.now()
        }

        self._subscriptions[user_id] = subscription

        return {
            "success": True,
            "message": f"Successfully subscribed to {plan.plan_name}",
            "subscription": subscription
        }

    def cancel_subscription(
        self,
        user_id: str,
        immediate: bool = False
    ) -> Dict:
        """
        Cancel a user's subscription

        Args:
            user_id: User identifier
            immediate: If True, cancel immediately; otherwise, cancel at period end

        Returns:
            Cancellation confirmation dict
        """
        if user_id not in self._subscriptions:
            return {"success": False, "error": "No active subscription found"}

        subscription = self._subscriptions[user_id]

        if immediate:
            subscription["status"] = "cancelled"
            subscription["cancelled_at"] = datetime.now()
            message = "Subscription cancelled immediately"
        else:
            subscription["status"] = "cancelling"
            subscription["cancel_at_period_end"] = True
            message = f"Subscription will end on {subscription['next_billing_date']}"

        return {"success": True, "message": message}

    def get_subscription(self, user_id: str) -> Optional[Dict]:
        """Get user's current subscription"""
        return self._subscriptions.get(user_id)

    def upgrade_subscription(self, user_id: str, new_plan_id: str) -> Dict:
        """
        Upgrade user's subscription to a higher plan

        Args:
            user_id: User identifier
            new_plan_id: New plan ID to upgrade to

        Returns:
            Upgrade confirmation dict
        """
        if user_id not in self._subscriptions:
            return {"success": False, "error": "No active subscription found"}

        new_plan = self.pricing_config.get_subscription_plan(new_plan_id)
        if not new_plan:
            return {"success": False, "error": f"Invalid plan ID: {new_plan_id}"}

        old_subscription = self._subscriptions[user_id]
        old_plan = self.pricing_config.get_subscription_plan(old_subscription["plan_id"])

        # Prorate logic could be added here
        prorated_amount = (new_plan.monthly_fee - old_plan.monthly_fee) / 2

        # Update subscription
        old_subscription["plan_id"] = new_plan_id
        old_subscription["plan_name"] = new_plan.plan_name
        old_subscription["monthly_fee"] = new_plan.monthly_fee
        old_subscription["included_token_credits"] = new_plan.included_token_credits
        old_subscription["included_api_calls"] = new_plan.included_api_calls
        old_subscription["upgraded_at"] = datetime.now()
        old_subscription["prorated_amount"] = prorated_amount

        return {
            "success": True,
            "message": f"Upgraded to {new_plan.plan_name}",
            "prorated_amount": prorated_amount,
            "subscription": old_subscription
        }

    # ==================== Usage Tracking ====================

    def track_llm_usage(
        self,
        user_id: str,
        model_name: str,
        input_tokens: int,
        output_tokens: int,
        workflow_id: Optional[str] = None,
        agent_id: Optional[str] = None
    ):
        """Track LLM token usage for a user"""
        self.usage_tracker.track_llm_usage(
            user_id=user_id,
            model_name=model_name,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            workflow_id=workflow_id,
            agent_id=agent_id
        )

    def track_marketing_api_call(
        self,
        user_id: str,
        platform: str,
        endpoint: str,
        call_type: str,
        count: int,
        campaign_id: Optional[str] = None
    ):
        """Track marketing API call for a user"""
        self.usage_tracker.track_marketing_api_call(
            user_id=user_id,
            platform=platform,
            endpoint=endpoint,
            call_type=call_type,
            count=count,
            campaign_id=campaign_id
        )

    def get_current_usage(self, user_id: str) -> Dict:
        """
        Get current period usage summary for a user

        Returns:
            Usage summary dict with token and API call breakdowns
        """
        record = self.usage_tracker.get_user_usage(user_id)
        if not record:
            return {"token_usage": {}, "api_calls": {}, "workflow_executions": 0}

        return {
            "token_usage": self.usage_tracker.get_aggregated_token_usage(user_id),
            "api_calls": self.usage_tracker.get_aggregated_api_calls(user_id),
            "workflow_executions": record.workflow_executions
        }

    def get_usage_against_limits(self, user_id: str) -> Dict:
        """
        Get usage compared to subscription limits

        Returns:
            Dict showing usage vs included limits
        """
        subscription = self._subscriptions.get(user_id)
        if not subscription:
            return {"error": "No active subscription"}

        usage = self.get_current_usage(user_id)

        # Calculate total tokens used
        total_tokens = sum(
            data["total"] for data in usage["token_usage"].values()
        )

        # Calculate total API calls
        total_api_calls = sum(
            data.get("calls", 0) for data in usage["api_calls"].values()
        )

        return {
            "plan": subscription["plan_name"],
            "tokens": {
                "used": total_tokens,
                "included": subscription["included_token_credits"],
                "remaining": max(0, subscription["included_token_credits"] - total_tokens),
                "overage": max(0, total_tokens - subscription["included_token_credits"])
            },
            "api_calls": {
                "used": total_api_calls,
                "included": subscription["included_api_calls"],
                "remaining": max(0, subscription["included_api_calls"] - total_api_calls),
                "overage": max(0, total_api_calls - subscription["included_api_calls"])
            }
        }

    # ==================== Invoice Generation ====================

    def generate_invoice(
        self,
        user_id: str,
        period: Optional[str] = None,
        tax_rate: Optional[float] = None,
        discount: float = 0.0
    ) -> Invoice:
        """
        Generate invoice for a user

        Args:
            user_id: User identifier
            period: Billing period (YYYY-MM format)
            tax_rate: Tax rate override
            discount: Discount amount

        Returns:
            Complete Invoice object
        """
        subscription = self._subscriptions.get(user_id)
        if not subscription:
            raise ValueError(f"No active subscription for user: {user_id}")

        return self.invoice_generator.generate_invoice(
            user_id=user_id,
            plan_id=subscription["plan_id"],
            period=period,
            tax_rate=tax_rate,
            discount=discount
        )

    def generate_cost_estimate(
        self,
        user_id: str,
        projected_token_usage: Dict[str, int],
        projected_api_calls: Dict[str, int],
        plan_id: Optional[str] = None
    ) -> Invoice:
        """
        Generate cost estimate based on projected usage

        Args:
            user_id: User identifier
            projected_token_usage: {model_name: token_count}
            projected_api_calls: {platform: call_count}
            plan_id: Plan to use for estimate (uses current plan if not specified)

        Returns:
            Invoice object marked as estimate
        """
        if plan_id is None:
            subscription = self._subscriptions.get(user_id)
            if not subscription:
                raise ValueError(f"No active subscription for user: {user_id}")
            plan_id = subscription["plan_id"]

        return self.invoice_generator.generate_estimate(
            user_id=user_id,
            plan_id=plan_id,
            projected_token_usage=projected_token_usage,
            projected_api_calls=projected_api_calls
        )

    # ==================== Billing Analytics ====================

    def get_billing_summary(self, user_id: str) -> Dict:
        """
        Get comprehensive billing summary for a user

        Returns:
            Complete billing summary including subscription, usage, and costs
        """
        subscription = self._subscriptions.get(user_id)
        if not subscription:
            return {"error": "No active subscription"}

        usage_limits = self.get_usage_against_limits(user_id)
        current_usage = self.get_current_usage(user_id)

        # Estimate current period charges
        estimated_charges = self._estimate_current_charges(user_id)

        return {
            "subscription": {
                "plan": subscription["plan_name"],
                "monthly_fee": subscription["monthly_fee"],
                "status": subscription["status"],
                "next_billing_date": str(subscription["next_billing_date"])
            },
            "usage_limits": usage_limits,
            "current_usage": current_usage,
            "estimated_charges": estimated_charges,
            "generated_at": datetime.now().isoformat()
        }

    def _estimate_current_charges(self, user_id: str) -> Dict:
        """Estimate charges for current period"""
        subscription = self._subscriptions.get(user_id)
        if not subscription:
            return {}

        record = self.usage_tracker.get_user_usage(user_id)
        if not record:
            return {"estimated_total": subscription["monthly_fee"]}

        # Create temporary invoice generator for estimation
        temp_generator = InvoiceGenerator(
            usage_tracker=self.usage_tracker,
            pricing_config=self.pricing_config
        )

        # Calculate LLM charges
        llm_items = temp_generator.calculate_llm_charges(
            record,
            subscription["included_token_credits"]
        )
        llm_charges = sum(item.total for item in llm_items)

        # Calculate API charges
        api_items = temp_generator.calculate_api_charges(
            record,
            subscription["included_api_calls"]
        )
        api_charges = sum(item.total for item in api_items)

        return {
            "base_fee": subscription["monthly_fee"],
            "llm_overage": max(0, llm_charges),
            "api_overage": max(0, api_charges),
            "estimated_total": subscription["monthly_fee"] + max(0, llm_charges) + max(0, api_charges)
        }

    def export_billing_data(
        self,
        user_id: str,
        format: str = "json"
    ) -> str:
        """
        Export billing data for a user

        Args:
            user_id: User identifier
            format: Output format ('json' or 'csv')

        Returns:
            Formatted billing data string
        """
        summary = self.get_billing_summary(user_id)

        if format.lower() == "json":
            return json.dumps(summary, indent=2, default=str)
        elif format.lower() == "csv":
            # Simple CSV export
            lines = ["metric,value"]
            lines.append(f"plan,{summary['subscription']['plan']}")
            lines.append(f"monthly_fee,{summary['subscription']['monthly_fee']}")
            lines.append(f"status,{summary['subscription']['status']}")

            tokens = summary['usage_limits']['tokens']
            lines.append(f"tokens_used,{tokens['used']}")
            lines.append(f"tokens_included,{tokens['included']}")

            api = summary['usage_limits']['api_calls']
            lines.append(f"api_calls_used,{api['used']}")
            lines.append(f"api_calls_included,{api['included']}")

            return "\n".join(lines)
        else:
            raise ValueError(f"Unsupported format: {format}")

    # ==================== Payment Integration Hooks ====================

    def add_payment_method(
        self,
        user_id: str,
        payment_method_id: str,
        payment_method_type: str,
        details: Dict
    ):
        """
        Add payment method for a user (integration point)

        This is a hook for integrating with payment processors like Stripe, PayPal, etc.
        """
        self._payment_methods[user_id] = {
            "payment_method_id": payment_method_id,
            "type": payment_method_type,
            "details": details,
            "added_at": datetime.now()
        }

    def process_payment(self, user_id: str, amount: float, invoice_id: str) -> Dict:
        """
        Process payment for an invoice (integration point)

        This is a hook for integrating with payment processors.
        Currently returns a mock response.
        """
        if user_id not in self._payment_methods:
            return {"success": False, "error": "No payment method on file"}

        # Mock payment processing
        # In production, integrate with Stripe, PayPal, etc.
        return {
            "success": True,
            "transaction_id": f"TXN-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "amount": amount,
            "currency": "USD",
            "invoice_id": invoice_id,
            "status": "completed",
            "processed_at": datetime.now().isoformat()
        }

    def setup_auto_billing(self, user_id: str) -> Dict:
        """
        Setup automatic billing for a user (integration point)

        Configures automatic charging at each billing cycle.
        """
        subscription = self._subscriptions.get(user_id)
        if not subscription:
            return {"success": False, "error": "No active subscription"}

        if user_id not in self._payment_methods:
            return {"success": False, "error": "No payment method on file"}

        subscription["auto_billing_enabled"] = True

        return {
            "success": True,
            "message": "Auto-billing enabled",
            "next_charge_date": str(subscription["next_billing_date"]),
            "next_charge_amount": subscription["monthly_fee"]
        }


# Import timedelta at module level
from datetime import timedelta