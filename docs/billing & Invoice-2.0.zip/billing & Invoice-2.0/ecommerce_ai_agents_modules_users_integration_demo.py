--- ecommerce_ai_agents/modules/users/integration_demo.py (原始)


+++ ecommerce_ai_agents/modules/users/integration_demo.py (修改后)
"""
集成示例 - 用户模块与计费模块联合使用
演示完整的用户注册、订阅、支付、使用计费等流程
"""

import sys
sys.path.insert(0, '/workspace')

from ecommerce_ai_agents.modules.users.user_manager import (
    AuthProvider, PaymentMethodType, UserManager, User
)
from ecommerce_ai_agents.billing.pricing_config import SubscriptionPlan
from ecommerce_ai_agents.billing.usage_tracker import UsageTracker
from ecommerce_ai_agents.billing.invoice_generator import InvoiceGenerator
from ecommerce_ai_agents.billing.billing_manager import BillingManager


def demo_integrated_workflow():
    """演示完整的集成工作流"""

    print("=" * 70)
    print("跨境电商AI工具集合 - 用户与计费集成演示")
    print("=" * 70)

    # 初始化各模块
    user_manager = UserManager()
    usage_tracker = UsageTracker()
    invoice_generator = InvoiceGenerator(usage_tracker)
    billing_manager = BillingManager(usage_tracker, invoice_generator)

    # ========== 1. 用户注册 ==========
    print("\n【步骤1】用户注册")
    print("-" * 70)

    # 中国用户 - 微信一键登录
    wechat_user = user_manager.login_with_oauth(
        provider=AuthProvider.WECHAT,
        provider_user_id="wechat_cn_888888",
        provider_info={
            "name": "李明",
            "email": "liming@wechat.com",
            "country": "CN",
            "language": "zh",
            "email_verified": True
        }
    )
    print(f"✓ 中国用户注册成功: {wechat_user.email}")
    print(f"  用户ID: {wechat_user.user_id}")
    print(f"  认证方式: {[p['provider'] for p in wechat_user.auth_providers]}")

    # 美国用户 - Google一键登录
    google_user = user_manager.login_with_oauth(
        provider=AuthProvider.GOOGLE,
        provider_user_id="google_us_999999",
        provider_info={
            "name": "John Smith",
            "email": "john.smith@gmail.com",
            "first_name": "John",
            "last_name": "Smith",
            "country": "US",
            "language": "en",
            "email_verified": True
        }
    )
    print(f"✓ 美国用户注册成功: {google_user.email}")
    print(f"  用户ID: {google_user.user_id}")

    # 欧洲用户 - 邮箱注册
    eu_user = user_manager.register_with_email(
        email="marie.dupont@example.fr",
        password="SecurePass2024!",
        username="marie_dupont",
        first_name="Marie",
        last_name="Dupont",
        country="FR"
    )
    print(f"✓ 欧洲用户注册成功: {eu_user.email}")

    # ========== 2. 添加支付方式 ==========
    print("\n【步骤2】添加支付方式")
    print("-" * 70)

    # 中国用户添加支付宝和微信支付
    alipay_pm = user_manager.add_payment_method(
        wechat_user.user_id,
        PaymentMethodType.ALIPAY_CN,
        {"account": "138****5678", "real_name": "李*"},
        is_default=True
    )
    print(f"✓ 中国用户添加支付宝: {alipay_pm['id']}")

    wechat_pay_pm = user_manager.add_payment_method(
        wechat_user.user_id,
        PaymentMethodType.WECHAT_PAY,
        {"openid": "wx_openid_123456"}
    )
    print(f"✓ 中国用户添加微信支付: {wechat_pay_pm['id']}")

    # 美国用户添加信用卡和PayPal
    visa_pm = user_manager.add_payment_method(
        google_user.user_id,
        PaymentMethodType.CREDIT_CARD,
        {
            "last_four": "4242",
            "brand": "visa",
            "exp_month": 12,
            "exp_year": 2026,
            "cardholder_name": "John Smith"
        },
        is_default=True
    )
    print(f"✓ 美国用户添加Visa卡: {visa_pm['id']}")

    paypal_pm = user_manager.add_payment_method(
        google_user.user_id,
        PaymentMethodType.PAYPAL,
        {"email": "john.smith@paypal.com"}
    )
    print(f"✓ 美国用户添加PayPal: {paypal_pm['id']}")

    # 欧洲用户添加SEPA银行卡
    sepa_pm = user_manager.add_payment_method(
        eu_user.user_id,
        PaymentMethodType.DEBIT_CARD,
        {
            "iban": "FR76****1234",
            "bic": "BNPAFRPP",
            "cardholder_name": "Marie Dupont"
        },
        is_default=True
    )
    print(f"✓ 欧洲用户添加借记卡: {sepa_pm['id']}")

    # ========== 3. 订阅套餐 ==========
    print("\n【步骤3】订阅套餐计划")
    print("-" * 70)

    # 中国用户订阅Professional套餐
    wechat_subscribed = user_manager.subscribe_to_plan(
        wechat_user.user_id,
        plan_id="professional"
    )
    print(f"✓ 中国用户订阅: {wechat_subscribed.subscription_plan}")
    print(f"  状态: {wechat_subscribed.subscription_status.value}")
    print(f"  有效期至: {wechat_subscribed.subscription_end.strftime('%Y-%m-%d')}")

    # 美国用户订阅Enterprise套餐
    google_subscribed = user_manager.subscribe_to_plan(
        google_user.user_id,
        plan_id="enterprise"
    )
    print(f"✓ 美国用户订阅: {google_subscribed.subscription_plan}")
    print(f"  状态: {google_subscribed.subscription_status.value}")

    # 欧洲用户订阅Starter套餐（试用）
    eu_subscribed = user_manager.subscribe_to_plan(
        eu_user.user_id,
        plan_id="starter"
    )
    print(f"✓ 欧洲用户订阅: {eu_subscribed.subscription_plan}")

    # ========== 4. 模拟使用工作流 ==========
    print("\n【步骤4】模拟用户使用AI工作流")
    print("-" * 70)

    # 中国用户使用营销工作流
    print("\n中国用户使用在线营销工作流:")
    usage_tracker.track_workflow_execution(
        user_id=wechat_user.user_id,

    )
    print("  ✓ 执行营销工作流 5 次")

    # 使用LLM Token
    usage_tracker.track_llm_usage(
        user_id=wechat_user.user_id,

        model_name="gpt-4",
        input_tokens=15000,
        output_tokens=5000
    )
    print("  ✓ 使用 GPT-4: 输入15K tokens, 输出5K tokens")

    # 调用TikTok营销API
    usage_tracker.track_marketing_api_call(
        user_id=wechat_user.user_id,

        platform="tiktok",
        count=50
    )
    print("  ✓ 调用 TikTok API 50 次")

    # 美国用户使用数据分析工作流
    print("\n美国用户使用数据分析工作流:")
    usage_tracker.track_workflow_execution(
        user_id=google_user.user_id,

    )
    print("  ✓ 执行数据分析工作流 10 次")

    usage_tracker.track_llm_usage(
        user_id=google_user.user_id,

        model_name="claude-3-opus",
        input_tokens=50000,
        output_tokens=20000
    )
    print("  ✓ 使用 Claude-3-Opus: 输入50K tokens, 输出20K tokens")

    # 调用多个营销API
    usage_tracker.track_marketing_api_call(
        user_id=google_user.user_id,

        platform="facebook",
        count=100
    )
    usage_tracker.track_marketing_api_call(
        user_id=google_user.user_id,

        platform="google_ads",
        count=75
    )
    print("  ✓ 调用 Facebook API 100 次, Google Ads API 75 次")

    # 欧洲用户使用内容创作工作流
    print("\n欧洲用户使用内容创作工作流:")
    usage_tracker.track_workflow_execution(
        user_id=eu_user.user_id,

    )
    print("  ✓ 执行内容创作工作流 3 次")

    usage_tracker.track_llm_usage(
        user_id=eu_user.user_id,

        model_name="gemini-pro",
        input_tokens=8000,
        output_tokens=4000
    )
    print("  ✓ 使用 Gemini-Pro: 输入8K tokens, 输出4K tokens")

    # ========== 5. 生成账单 ==========
    print("\n【步骤5】生成月度账单")
    print("-" * 70)

    # 获取当前月份
    from datetime import datetime
    current_month = datetime.now().strftime("%Y-%m")

    # 为中国用户生成账单
    print("\n中国用户账单:")
    wechat_invoice = billing_manager.generate_monthly_invoice(
        user_id=wechat_user.user_id,
        month=current_month
    )
    print(f"  发票ID: {wechat_invoice.invoice_id}")
    print(f"  套餐费用: ${wechat_invoice.subscription_fee:.2f}")
    print(f"  LLM Token费用: ${wechat_invoice.llm_cost:.2f}")
    print(f"  营销API费用: ${wechat_invoice.marketing_api_cost:.2f}")
    print(f"  超额费用: ${wechat_invoice.overage_charges:.2f}")
    print(f"  税费: ${wechat_invoice.tax_amount:.2f}")
    print(f"  总计: ${wechat_invoice.total_amount:.2f}")

    # 为美国用户生成账单
    print("\n美国用户账单:")
    google_invoice = billing_manager.generate_monthly_invoice(
        user_id=google_user.user_id,
        month=current_month
    )
    print(f"  发票ID: {google_invoice.invoice_id}")
    print(f"  套餐费用: ${google_invoice.subscription_fee:.2f}")
    print(f"  LLM Token费用: ${google_invoice.llm_cost:.2f}")
    print(f"  营销API费用: ${google_invoice.marketing_api_cost:.2f}")
    print(f"  超额费用: ${google_invoice.overage_charges:.2f}")
    print(f"  税费: ${google_invoice.tax_amount:.2f}")
    print(f"  总计: ${google_invoice.total_amount:.2f}")

    # 为欧洲用户生成账单
    print("\n欧洲用户账单:")
    eu_invoice = billing_manager.generate_monthly_invoice(
        user_id=eu_user.user_id,
        month=current_month
    )
    print(f"  发票ID: {eu_invoice.invoice_id}")
    print(f"  套餐费用: ${eu_invoice.subscription_fee:.2f}")
    print(f"  LLM Token费用: ${eu_invoice.llm_cost:.2f}")
    print(f"  营销API费用: ${eu_invoice.marketing_api_cost:.2f}")
    print(f"  总计: ${eu_invoice.total_amount:.2f}")

    # ========== 6. 查看使用统计 ==========
    print("\n【步骤6】用户使用统计")
    print("-" * 70)

    wechat_usage = usage_tracker.get_user_usage_summary(wechat_user.user_id)
    print(f"\n中国用户使用情况:")
    print(f"  工作流执行次数: {wechat_usage['total_workflows']}")
    print(f"  总Token使用量: {wechat_usage['total_tokens']}")
    print(f"  营销API调用: {wechat_usage['total_api_calls']}")
    print(f"  预估总费用: ${wechat_usage['estimated_cost']:.2f}")

    google_usage = usage_tracker.get_user_usage_summary(google_user.user_id)
    print(f"\n美国用户使用情况:")
    print(f"  工作流执行次数: {google_usage['total_workflows']}")
    print(f"  总Token使用量: {google_usage['total_tokens']}")
    print(f"  营销API调用: {google_usage['total_api_calls']}")
    print(f"  预估总费用: ${google_usage['estimated_cost']:.2f}")

    eu_usage = usage_tracker.get_user_usage_summary(eu_user.user_id)
    print(f"\n欧洲用户使用情况:")
    print(f"  工作流执行次数: {eu_usage['total_workflows']}")
    print(f"  总Token使用量: {eu_usage['total_tokens']}")
    print(f"  营销API调用: {eu_usage['total_api_calls']}")
    print(f"  预估总费用: ${eu_usage['estimated_cost']:.2f}")

    # ========== 7. 成本估算 ==========
    print("\n【步骤7】下月成本估算")
    print("-" * 70)

    # 假设下月使用量增长50%
    print("\n基于当前使用量预测下月费用（假设增长50%）:")

    wechat_forecast = billing_manager.estimate_future_costs(
        user_id=wechat_user.user_id,
        multiplier=1.5
    )
    print(f"\n中国用户预估:")
    print(f"  预计LLM费用: ${wechat_forecast['estimated_llm_cost']:.2f}")
    print(f"  预计API费用: ${wechat_forecast['estimated_api_cost']:.2f}")
    print(f"  预计总额: ${wechat_forecast['total_estimated_cost']:.2f}")

    google_forecast = billing_manager.estimate_future_costs(
        user_id=google_user.user_id,
        multiplier=1.5
    )
    print(f"\n美国用户预估:")
    print(f"  预计LLM费用: ${google_forecast['estimated_llm_cost']:.2f}")
    print(f"  预计API费用: ${google_forecast['estimated_api_cost']:.2f}")
    print(f"  预计总额: ${google_forecast['total_estimated_cost']:.2f}")

    # ========== 8. 导出详细发票 ==========
    print("\n【步骤8】查看详细发票明细")
    print("-" * 70)

    print("\n美国用户详细发票项目:")
    for item in google_invoice.line_items:
        print(f"  - {item['description']}: ${item['amount']:.2f}")

    print("\n" + "=" * 70)
    print("集成演示完成!")
    print("=" * 70)

    return {
        "users": [wechat_user, google_user, eu_user],
        "invoices": [wechat_invoice, google_invoice, eu_invoice],
        "usage_summaries": [wechat_usage, google_usage, eu_usage]
    }


if __name__ == "__main__":
    result = demo_integrated_workflow()