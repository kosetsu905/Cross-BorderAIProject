\--- ecommerce\_ai\_agents/billing/README.md (原始)



+++ ecommerce\_ai\_agents/billing/README.md (修改后)

# Billing Module for E-commerce AI Agents

## Overview

The billing module provides comprehensive monetization capabilities for the E-commerce AI Agents platform, supporting:

1. **Monthly Subscription Fees** - Multiple pricing tiers with included credits
2. **LLM Token Usage Billing** - Multi-model support with per-token pricing
3. **Marketing API Call Billing** - TikTok, Facebook, Google Ads, LinkedIn, etc.
4. **Invoice Generation** - Detailed itemized invoices with tax support
5. **Cost Estimation** - Project future costs based on usage patterns
6. **Payment Integration** - Hooks for Stripe, PayPal, and other processors

## Architecture

```
billing/
├── \_\_init\_\_.py              # Module exports
├── pricing\_config.py        # Pricing configurations for all services
├── usage\_tracker.py         # Real-time usage tracking
├── invoice\_generator.py     # Invoice generation and formatting
└── billing\_manager.py       # Central billing orchestrator
```

## Features

### 1\. Subscription Plans

Four pre-configured plans:

* **Starter** ($29.99/mo) - 50K tokens, 1K API calls
* **Professional** ($99.99/mo) - 200K tokens, 5K API calls
* **Enterprise** ($299.99/mo) - 1M tokens, 25K API calls
* **Custom** - Tailored pricing

### 2\. LLM Model Pricing

Supports multiple LLM providers:

* OpenAI (GPT-4, GPT-4-Turbo, GPT-3.5-Turbo)
* Anthropic (Claude-3 Opus, Sonnet, Haiku)
* Google (Gemini-Pro)
* Meta (Llama-3-70B)

### 3\. Marketing Platform Pricing

Track costs across platforms:

* TikTok (calls, impressions, clicks)
* Facebook/Instagram
* Google Ads
* LinkedIn
* Twitter

## Quick Start

```python
import sys
sys.path.insert(0, '/workspace')

from ecommerce\_ai\_agents.billing.billing\_manager import BillingManager

# Initialize billing manager
billing = BillingManager(default\_tax\_rate=0.08)  # 8% tax

# Subscribe a user
result = billing.subscribe\_user(
    user\_id="user\_123",
    plan\_id="professional",
    auto\_renew=True
)

# Track LLM usage
billing.track\_llm\_usage(
    user\_id="user\_123",
    model\_name="gpt-4",
    input\_tokens=5000,
    output\_tokens=2000,
    workflow\_id="content\_workflow\_001"
)

# Track marketing API calls
billing.track\_marketing\_api\_call(
    user\_id="user\_123",
    platform="tiktok",
    endpoint="/api/v1/campaign/create",
    call\_type="call",
    count=150
)

# Generate invoice
invoice = billing.generate\_invoice(user\_id="user\_123")
print(invoice.format\_summary())

# Get billing summary
summary = billing.get\_billing\_summary("user\_123")
print(f"Estimated Total: ${summary\['estimated\_charges']\['estimated\_total']:.2f}")
```

## API Reference

### BillingManager

#### Subscription Management

* `subscribe\_user(user\_id, plan\_id, start\_date, auto\_renew)` - Subscribe user to plan
* `cancel\_subscription(user\_id, immediate)` - Cancel subscription
* `upgrade\_subscription(user\_id, new\_plan\_id)` - Upgrade to higher plan
* `get\_subscription(user\_id)` - Get current subscription

#### Usage Tracking

* `track\_llm\_usage(user\_id, model\_name, input\_tokens, output\_tokens, ...)` - Track LLM tokens
* `track\_marketing\_api\_call(user\_id, platform, endpoint, call\_type, count)` - Track API calls
* `get\_current\_usage(user\_id)` - Get current period usage
* `get\_usage\_against\_limits(user\_id)` - Compare usage vs limits

#### Invoicing

* `generate\_invoice(user\_id, period, tax\_rate, discount)` - Generate invoice
* `generate\_cost\_estimate(user\_id, projected\_token\_usage, projected\_api\_calls)` - Estimate costs

#### Analytics

* `get\_billing\_summary(user\_id)` - Comprehensive billing summary
* `export\_billing\_data(user\_id, format)` - Export as JSON or CSV

#### Payment Integration

* `add\_payment\_method(user\_id, payment\_method\_id, type, details)` - Add payment method
* `process\_payment(user\_id, amount, invoice\_id)` - Process payment
* `setup\_auto\_billing(user\_id)` - Enable automatic billing

### PricingConfig

Access pricing information:

```python
from ecommerce\_ai\_agents.billing.pricing\_config import PricingConfig

# Get LLM pricing
gpt4\_pricing = PricingConfig.get\_llm\_pricing("gpt-4")
cost = gpt4\_pricing.calculate\_cost(input\_tokens=1000, output\_tokens=500)

# Get marketing API pricing
tiktok\_pricing = PricingConfig.get\_marketing\_api\_pricing("tiktok")
cost = tiktok\_pricing.calculate\_cost(calls=100, impressions=10000, clicks=50)

# Get subscription plan
plan = PricingConfig.get\_subscription\_plan("professional")
print(f"Monthly fee: ${plan.monthly\_fee}")
```

### UsageTracker

Direct usage tracking:

```python
from ecommerce\_ai\_agents.billing.usage\_tracker import UsageTracker

tracker = UsageTracker()

# Track usage
tracker.track\_llm\_usage("user\_123", "gpt-4", 5000, 2000)
tracker.track\_marketing\_api\_call("user\_123", "tiktok", "/api/v1", "call", 100)

# Get aggregated usage
token\_usage = tracker.get\_aggregated\_token\_usage("user\_123")
api\_calls = tracker.get\_aggregated\_api\_calls("user\_123")
```

### InvoiceGenerator

Generate detailed invoices:

```python
from ecommerce\_ai\_agents.billing.invoice\_generator import InvoiceGenerator
from ecommerce\_ai\_agents.billing.usage\_tracker import UsageTracker

tracker = UsageTracker()
generator = InvoiceGenerator(usage\_tracker=tracker, default\_tax\_rate=0.08)

invoice = generator.generate\_invoice(
    user\_id="user\_123",
    plan\_id="professional",
    discount=10.0
)

# Output formats
print(invoice.format\_summary())  # Human-readable
json\_str = invoice.to\_json()      # JSON format
dict\_data = invoice.to\_dict()     # Dictionary
```

## Pricing Details

### LLM Models (per 1K tokens)

|Model|Input|Output|
|-|-|-|
|GPT-4|$0.03|$0.06|
|GPT-4-Turbo|$0.01|$0.03|
|GPT-3.5-Turbo|$0.0005|$0.0015|
|Claude-3-Opus|$0.015|$0.075|
|Claude-3-Sonnet|$0.003|$0.015|
|Claude-3-Haiku|$0.00025|$0.00125|
|Gemini-Pro|$0.00025|$0.0005|
|Llama-3-70B|$0.0008|$0.0008|

### Marketing APIs

|Platform|Per Call|Per 1K Impressions|Per Click|
|-|-|-|-|
|TikTok|$0.001|$0.01|$0.02|
|Facebook|$0.001|$0.01|$0.015|
|Google Ads|$0.001|$0.01|$0.025|
|LinkedIn|$0.002|$0.02|$0.05|

## Examples

Run the comprehensive examples:

```bash
cd /workspace
python ecommerce\_ai\_agents/billing/examples.py
```

This demonstrates:

1. Subscription management
2. Multi-model LLM tracking
3. Marketing API tracking (TikTok, Facebook, Google)
4. Invoice generation
5. Cost estimation
6. Billing analytics
7. Payment integration

## Integration with Workflows

Integrate billing into your AI agent workflows:

```python
from ecommerce\_ai\_agents.billing.billing\_manager import BillingManager

billing = BillingManager()

# In your workflow execution
def execute\_workflow(user\_id, workflow\_type, llm\_model):
    # Before execution
    subscription = billing.get\_subscription(user\_id)
    if not subscription:
        raise Exception("No active subscription")

    # Execute workflow and capture token usage
    response = call\_llm(model=llm\_model, prompt=prompt)

    # Track usage after execution
    billing.track\_llm\_usage(
        user\_id=user\_id,
        model\_name=llm\_model,
        input\_tokens=len(prompt\_tokens),
        output\_tokens=len(response\_tokens),
        workflow\_id=workflow\_type
    )

    # Check if approaching limits
    usage = billing.get\_usage\_against\_limits(user\_id)
    if usage\['tokens']\['remaining'] < 10000:
        send\_warning\_email(user\_id, usage)

    return response
```

## Custom Pricing

Add custom pricing for new models or platforms:

```python
from ecommerce\_ai\_agents.billing.pricing\_config import PricingConfig

# Add custom LLM pricing
PricingConfig.add\_custom\_llm\_pricing(
    model\_name="custom-model",
    input\_price=0.001,
    output\_price=0.002
)

# Add custom marketing API pricing
PricingConfig.add\_custom\_marketing\_api\_pricing(
    platform="pinterest",
    price\_per\_call=0.001,
    price\_per\_impression=0.00001,
    price\_per\_click=0.015
)
```

## Payment Processor Integration

The module provides hooks for payment processor integration:

```python
# Stripe integration example
def integrate\_stripe(billing\_manager):
    import stripe

    @billing\_manager.process\_payment
    def stripe\_payment(user\_id, amount, invoice\_id):
        customer\_id = get\_stripe\_customer\_id(user\_id)

        payment\_intent = stripe.PaymentIntent.create(
            amount=int(amount \* 100),  # Convert to cents
            currency="usd",
            customer=customer\_id,
            metadata={"invoice\_id": invoice\_id}
        )

        return {
            "success": payment\_intent.status == "succeeded",
            "transaction\_id": payment\_intent.id,
            "amount": amount,
            "status": payment\_intent.status
        }
```

## Best Practices

1. **Track Usage in Real-Time**: Call tracking methods immediately after API calls
2. **Monitor Limits**: Regularly check `get\_usage\_against\_limits()` to prevent overages
3. **Generate Estimates**: Use cost estimates to help users predict expenses
4. **Export Data**: Regularly export billing data for record-keeping
5. **Set Up Auto-Billing**: Enable automatic payments for seamless experience

## Support

For questions or issues, please refer to the main README.md or contact support.

