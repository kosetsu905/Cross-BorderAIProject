--- ecommerce_ai_agents/billing/pricing_config.py (原始)


+++ ecommerce_ai_agents/billing/pricing_config.py (修改后)
"""
Pricing configuration for different services and models

Supports:
- Multiple LLM models with different pricing tiers
- Marketing API integrations (TikTok, Facebook, Google, etc.)
- Subscription plans
"""

from typing import Dict, Optional
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class LLMModelPricing:
    """Pricing for a specific LLM model"""
    model_name: str
    input_price_per_1k_tokens: float  # Price per 1000 input tokens
    output_price_per_1k_tokens: float  # Price per 1000 output tokens
    currency: str = "USD"

    def calculate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Calculate cost for given token usage"""
        input_cost = (input_tokens / 1000) * self.input_price_per_1k_tokens
        output_cost = (output_tokens / 1000) * self.output_price_per_1k_tokens
        return round(input_cost + output_cost, 6)


@dataclass
class MarketingAPIPricing:
    """Pricing for marketing API calls"""
    platform: str
    price_per_call: float
    price_per_impression: float = 0.0
    price_per_click: float = 0.0
    currency: str = "USD"

    def calculate_cost(
        self,
        calls: int = 0,
        impressions: int = 0,
        clicks: int = 0
    ) -> float:
        """Calculate cost for marketing API usage"""
        total = (calls * self.price_per_call) + \
                (impressions * self.price_per_impression) + \
                (clicks * self.price_per_click)
        return round(total, 6)


@dataclass
class SubscriptionPlan:
    """Subscription plan configuration"""
    plan_id: str
    plan_name: str
    monthly_fee: float
    included_token_credits: int = 0  # Included LLM tokens per month
    included_api_calls: int = 0  # Included marketing API calls per month
    features: list = field(default_factory=list)
    currency: str = "USD"


class PricingConfig:
    """Central pricing configuration manager"""

    # LLM Model Pricing (as of 2024, update as needed)
    LLM_PRICING: Dict[str, LLMModelPricing] = {
        "gpt-4": LLMModelPricing(
            model_name="gpt-4",
            input_price_per_1k_tokens=0.03,
            output_price_per_1k_tokens=0.06
        ),
        "gpt-4-turbo": LLMModelPricing(
            model_name="gpt-4-turbo",
            input_price_per_1k_tokens=0.01,
            output_price_per_1k_tokens=0.03
        ),
        "gpt-3.5-turbo": LLMModelPricing(
            model_name="gpt-3.5-turbo",
            input_price_per_1k_tokens=0.0005,
            output_price_per_1k_tokens=0.0015
        ),
        "claude-3-opus": LLMModelPricing(
            model_name="claude-3-opus",
            input_price_per_1k_tokens=0.015,
            output_price_per_1k_tokens=0.075
        ),
        "claude-3-sonnet": LLMModelPricing(
            model_name="claude-3-sonnet",
            input_price_per_1k_tokens=0.003,
            output_price_per_1k_tokens=0.015
        ),
        "claude-3-haiku": LLMModelPricing(
            model_name="claude-3-haiku",
            input_price_per_1k_tokens=0.00025,
            output_price_per_1k_tokens=0.00125
        ),
        "gemini-pro": LLMModelPricing(
            model_name="gemini-pro",
            input_price_per_1k_tokens=0.00025,
            output_price_per_1k_tokens=0.0005
        ),
        "llama-3-70b": LLMModelPricing(
            model_name="llama-3-70b",
            input_price_per_1k_tokens=0.0008,
            output_price_per_1k_tokens=0.0008
        ),
    }

    # Marketing API Pricing
    MARKETING_API_PRICING: Dict[str, MarketingAPIPricing] = {
        "tiktok": MarketingAPIPricing(
            platform="tiktok",
            price_per_call=0.001,
            price_per_impression=0.00001,
            price_per_click=0.02
        ),
        "facebook": MarketingAPIPricing(
            platform="facebook",
            price_per_call=0.001,
            price_per_impression=0.00001,
            price_per_click=0.015
        ),
        "google_ads": MarketingAPIPricing(
            platform="google_ads",
            price_per_call=0.001,
            price_per_impression=0.00001,
            price_per_click=0.025
        ),
        "instagram": MarketingAPIPricing(
            platform="instagram",
            price_per_call=0.001,
            price_per_impression=0.00001,
            price_per_click=0.018
        ),
        "linkedin": MarketingAPIPricing(
            platform="linkedin",
            price_per_call=0.002,
            price_per_impression=0.00002,
            price_per_click=0.05
        ),
        "twitter": MarketingAPIPricing(
            platform="twitter",
            price_per_call=0.001,
            price_per_impression=0.00001,
            price_per_click=0.02
        ),
    }

    # Subscription Plans
    SUBSCRIPTION_PLANS: Dict[str, SubscriptionPlan] = {
        "starter": SubscriptionPlan(
            plan_id="starter",
            plan_name="Starter Plan",
            monthly_fee=29.99,
            included_token_credits=50000,
            included_api_calls=1000,
            features=["Basic workflows", "Email support", "5 team members"]
        ),
        "professional": SubscriptionPlan(
            plan_id="professional",
            plan_name="Professional Plan",
            monthly_fee=99.99,
            included_token_credits=200000,
            included_api_calls=5000,
            features=[
                "All workflows",
                "Priority support",
                "20 team members",
                "Advanced analytics"
            ]
        ),
        "enterprise": SubscriptionPlan(
            plan_id="enterprise",
            plan_name="Enterprise Plan",
            monthly_fee=299.99,
            included_token_credits=1000000,
            included_api_calls=25000,
            features=[
                "All workflows",
                "24/7 dedicated support",
                "Unlimited team members",
                "Advanced analytics",
                "Custom integrations",
                "SLA guarantee"
            ]
        ),
        "custom": SubscriptionPlan(
            plan_id="custom",
            plan_name="Custom Plan",
            monthly_fee=0.0,  # Custom pricing
            included_token_credits=0,
            included_api_calls=0,
            features=["Tailored to your needs"]
        ),
    }

    @classmethod
    def get_llm_pricing(cls, model_name: str) -> Optional[LLMModelPricing]:
        """Get pricing for a specific LLM model"""
        return cls.LLM_PRICING.get(model_name.lower())

    @classmethod
    def get_marketing_api_pricing(cls, platform: str) -> Optional[MarketingAPIPricing]:
        """Get pricing for a specific marketing platform"""
        return cls.MARKETING_API_PRICING.get(platform.lower())

    @classmethod
    def get_subscription_plan(cls, plan_id: str) -> Optional[SubscriptionPlan]:
        """Get a specific subscription plan"""
        return cls.SUBSCRIPTION_PLANS.get(plan_id.lower())

    @classmethod
    def add_custom_llm_pricing(
        cls,
        model_name: str,
        input_price: float,
        output_price: float
    ):
        """Add custom LLM pricing"""
        cls.LLM_PRICING[model_name.lower()] = LLMModelPricing(
            model_name=model_name,
            input_price_per_1k_tokens=input_price,
            output_price_per_1k_tokens=output_price
        )

    @classmethod
    def add_custom_marketing_api_pricing(
        cls,
        platform: str,
        price_per_call: float,
        price_per_impression: float = 0.0,
        price_per_click: float = 0.0
    ):
        """Add custom marketing API pricing"""
        cls.MARKETING_API_PRICING[platform.lower()] = MarketingAPIPricing(
            platform=platform,
            price_per_call=price_per_call,
            price_per_impression=price_per_impression,
            price_per_click=price_per_click
        )