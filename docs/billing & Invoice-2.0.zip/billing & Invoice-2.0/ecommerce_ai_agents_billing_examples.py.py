--- ecommerce_ai_agents/billing/examples.py (原始)


+++ ecommerce_ai_agents/billing/examples.py (修改后)
"""
Comprehensive examples for the Billing Module

Demonstrates:
1. Subscription management
2. LLM token usage tracking (multi-model)
3. Marketing API call tracking (TikTok, Facebook, etc.)
4. Invoice generation
5. Cost estimation
6. Billing analytics
"""

import sys
sys.path.insert(0, '/workspace')

from ecommerce_ai_agents.billing.billing_manager import BillingManager
from ecommerce_ai_agents.billing.pricing_config import PricingConfig


def example_1_subscription_management():
    """Example 1: User subscription management"""
    print("\n" + "="*60)
    print("EXAMPLE 1: Subscription Management")
    print("="*60)

    # Initialize billing manager
    billing = BillingManager(default_tax_rate=0.08)  # 8% tax

    # Subscribe user to Professional plan
    result = billing.subscribe_user(
        user_id="user_123",
        plan_id="professional",
        auto_renew=True
    )
    print(f"\n✓ Subscription Result: {result['message']}")
    print(f"  Plan: {result['subscription']['plan_name']}")
    print(f"  Monthly Fee: ${result['subscription']['monthly_fee']}")
    print(f"  Included Tokens: {result['subscription']['included_token_credits']:,}")
    print(f"  Included API Calls: {result['subscription']['included_api_calls']:,}")

    # Get subscription details
    subscription = billing.get_subscription("user_123")
    print(f"\n✓ Current Subscription Status: {subscription['status']}")

    # Upgrade subscription
    upgrade_result = billing.upgrade_subscription("user_123", "enterprise")
    print(f"\n✓ Upgrade Result: {upgrade_result['message']}")
    print(f"  Prorated Amount: ${upgrade_result['prorated_amount']:.2f}")

    return billing


def example_2_llm_usage_tracking(billing: BillingManager):
    """Example 2: Track LLM token usage across multiple models"""
    print("\n" + "="*60)
    print("EXAMPLE 2: LLM Token Usage Tracking")
    print("="*60)

    user_id = "user_123"

    # Simulate various LLM usages across different workflows
    print("\n📊 Tracking LLM usage...")

    # GPT-4 usage for content creation
    billing.track_llm_usage(
        user_id=user_id,
        model_name="gpt-4",
        input_tokens=5000,
        output_tokens=2000,
        workflow_id="content_workflow_001",
        agent_id="content_agent"
    )
    print("  ✓ Tracked GPT-4: 5,000 input + 2,000 output tokens")

    # GPT-3.5-turbo for customer support
    billing.track_llm_usage(
        user_id=user_id,
        model_name="gpt-3.5-turbo",
        input_tokens=15000,
        output_tokens=8000,
        workflow_id="support_workflow_003",
        agent_id="support_agent"
    )
    print("  ✓ Tracked GPT-3.5-turbo: 15,000 input + 8,000 output tokens")

    # Claude-3-Sonnet for marketing analysis
    billing.track_llm_usage(
        user_id=user_id,
        model_name="claude-3-sonnet",
        input_tokens=8000,
        output_tokens=4000,
        workflow_id="marketing_workflow_002",
        agent_id="marketing_agent"
    )
    print("  ✓ Tracked Claude-3-Sonnet: 8,000 input + 4,000 output tokens")

    # Gemini-Pro for data analytics
    billing.track_llm_usage(
        user_id=user_id,
        model_name="gemini-pro",
        input_tokens=12000,
        output_tokens=6000,
        workflow_id="analytics_workflow_005",
        agent_id="analytics_agent"
    )
    print("  ✓ Tracked Gemini-Pro: 12,000 input + 6,000 output tokens")

    # Get current usage
    usage = billing.get_current_usage(user_id)
    print(f"\n📈 Current Token Usage Summary:")
    for model, data in usage["token_usage"].items():
        print(f"  • {model}: {data['total']:,} tokens "
              f"(in: {data['input_tokens']:,}, out: {data['output_tokens']:,})")

    return billing


def example_3_marketing_api_tracking(billing: BillingManager):
    """Example 3: Track marketing API calls (TikTok, Facebook, etc.)"""
    print("\n" + "="*60)
    print("EXAMPLE 3: Marketing API Call Tracking")
    print("="*60)

    user_id = "user_123"

    print("\n📊 Tracking marketing API calls...")

    # TikTok API calls
    billing.track_marketing_api_call(
        user_id=user_id,
        platform="tiktok",
        endpoint="/api/v1/campaign/create",
        call_type="call",
        count=150,
        campaign_id="tiktok_campaign_001"
    )
    print("  ✓ TikTok: 150 API calls")

    billing.track_marketing_api_call(
        user_id=user_id,
        platform="tiktok",
        endpoint="/api/v1/analytics/impressions",
        call_type="impression",
        count=50000,
        campaign_id="tiktok_campaign_001"
    )
    print("  ✓ TikTok: 50,000 impressions tracked")

    billing.track_marketing_api_call(
        user_id=user_id,
        platform="tiktok",
        endpoint="/api/v1/analytics/clicks",
        call_type="click",
        count=1200,
        campaign_id="tiktok_campaign_001"
    )
    print("  ✓ TikTok: 1,200 clicks tracked")

    # Facebook API calls
    billing.track_marketing_api_call(
        user_id=user_id,
        platform="facebook",
        endpoint="/api/v1/ads/create",
        call_type="call",
        count=200,
        campaign_id="fb_campaign_002"
    )
    print("  ✓ Facebook: 200 API calls")

    billing.track_marketing_api_call(
        user_id=user_id,
        platform="facebook",
        endpoint="/api/v1/ads/impressions",
        call_type="impression",
        count=75000,
        campaign_id="fb_campaign_002"
    )
    print("  ✓ Facebook: 75,000 impressions tracked")

    # Google Ads API calls
    billing.track_marketing_api_call(
        user_id=user_id,
        platform="google_ads",
        endpoint="/api/v1/campaigns",
        call_type="call",
        count=100,
        campaign_id="google_campaign_003"
    )
    print("  ✓ Google Ads: 100 API calls")

    billing.track_marketing_api_call(
        user_id=user_id,
        platform="google_ads",
        endpoint="/api/v1/clicks",
        call_type="click",
        count=800,
        campaign_id="google_campaign_003"
    )
    print("  ✓ Google Ads: 800 clicks tracked")

    # Get API usage summary
    usage = billing.get_current_usage(user_id)
    print(f"\n📈 Marketing API Usage Summary:")
    for platform, data in usage["api_calls"].items():
        print(f"  • {platform.capitalize()}:")
        if "calls" in data:
            print(f"      - Calls: {data['calls']:,}")
        if "impressions" in data:
            print(f"      - Impressions: {data['impressions']:,}")
        if "clicks" in data:
            print(f"      - Clicks: {data['clicks']:,}")

    return billing


def example_4_invoice_generation(billing: BillingManager):
    """Example 4: Generate detailed invoice"""
    print("\n" + "="*60)
    print("EXAMPLE 4: Invoice Generation")
    print("="*60)

    user_id = "user_123"

    # Generate invoice
    print("\n📄 Generating invoice...")
    invoice = billing.generate_invoice(user_id=user_id, discount=10.0)

    # Print formatted invoice
    print("\n" + invoice.format_summary())

    # Also available as JSON
    print(f"\n💾 Invoice ID: {invoice.invoice_id}")
    print(f"   Total Amount: ${invoice.total:.2f} {invoice.currency}")
    print(f"   Status: {invoice.status.upper()}")
    print(f"   Due Date: {invoice.payment_due_date}")

    return invoice


def example_5_cost_estimation(billing: BillingManager):
    """Example 5: Generate cost estimate for projected usage"""
    print("\n" + "="*60)
    print("EXAMPLE 5: Cost Estimation")
    print("="*60)

    user_id = "user_123"

    # Projected usage for next month
    projected_tokens = {
        "gpt-4": 50000,
        "gpt-3.5-turbo": 200000,
        "claude-3-sonnet": 30000,
        "gemini-pro": 40000
    }

    projected_api_calls = {
        "tiktok": 5000,
        "facebook": 8000,
        "google_ads": 3000,
        "linkedin": 1000
    }

    print("\n🔮 Projected Usage:")
    print("  Tokens:")
    for model, tokens in projected_tokens.items():
        print(f"    • {model}: {tokens:,}")
    print("  API Calls:")
    for platform, calls in projected_api_calls.items():
        print(f"    • {platform}: {calls:,}")

    # Generate estimate
    print("\n📄 Generating cost estimate...")
    estimate = billing.generate_cost_estimate(
        user_id=user_id,
        projected_token_usage=projected_tokens,
        projected_api_calls=projected_api_calls
    )

    print("\n" + estimate.format_summary())
    print(f"\n💡 Estimated Total: ${estimate.total:.2f} {estimate.currency}")

    return estimate


def example_6_billing_analytics(billing: BillingManager):
    """Example 6: Billing analytics and reporting"""
    print("\n" + "="*60)
    print("EXAMPLE 6: Billing Analytics")
    print("="*60)

    user_id = "user_123"

    # Get comprehensive billing summary
    print("\n📊 Generating billing summary...")
    summary = billing.get_billing_summary(user_id)

    print(f"\n{'='*50}")
    print(f"BILLING SUMMARY FOR {user_id}")
    print(f"{'='*50}")

    print(f"\n📦 Subscription:")
    print(f"   Plan: {summary['subscription']['plan']}")
    print(f"   Monthly Fee: ${summary['subscription']['monthly_fee']}")
    print(f"   Status: {summary['subscription']['status'].upper()}")
    print(f"   Next Billing: {summary['subscription']['next_billing_date']}")

    print(f"\n🎯 Usage vs Limits:")
    tokens = summary['usage_limits']['tokens']
    print(f"   Tokens: {tokens['used']:,} / {tokens['included']:,} "
          f"(Remaining: {tokens['remaining']:,})")
    if tokens['overage'] > 0:
        print(f"   ⚠️  Overage: {tokens['overage']:,} tokens")

    api = summary['usage_limits']['api_calls']
    print(f"   API Calls: {api['used']:,} / {api['included']:,} "
          f"(Remaining: {api['remaining']:,})")
    if api['overage'] > 0:
        print(f"   ⚠️  Overage: {api['overage']:,} calls")

    print(f"\n💰 Estimated Charges:")
    charges = summary['estimated_charges']
    print(f"   Base Fee: ${charges['base_fee']:.2f}")
    if charges.get('llm_overage', 0) > 0:
        print(f"   LLM Overage: ${charges['llm_overage']:.2f}")
    if charges.get('api_overage', 0) > 0:
        print(f"   API Overage: ${charges['api_overage']:.2f}")
    print(f"   ─────────────────")
    print(f"   Total: ${charges['estimated_total']:.2f}")

    # Export billing data
    print(f"\n💾 Exporting billing data...")
    json_data = billing.export_billing_data(user_id, format="json")
    print(f"   ✓ JSON export generated ({len(json_data)} bytes)")

    csv_data = billing.export_billing_data(user_id, format="csv")
    print(f"   ✓ CSV export generated")
    print("\n   CSV Preview:")
    for line in csv_data.split('\n')[:5]:
        print(f"     {line}")

    return summary


def example_7_payment_integration(billing: BillingManager):
    """Example 7: Payment processing integration"""
    print("\n" + "="*60)
    print("EXAMPLE 7: Payment Integration")
    print("="*60)

    user_id = "user_123"

    # Add payment method (mock)
    print("\n💳 Adding payment method...")
    billing.add_payment_method(
        user_id=user_id,
        payment_method_id="pm_1234567890",
        payment_method_type="credit_card",
        details={
            "brand": "visa",
            "last4": "4242",
            "exp_month": 12,
            "exp_year": 2025
        }
    )
    print("   ✓ Payment method added (Visa ending in 4242)")

    # Setup auto-billing
    print("\n🔄 Setting up auto-billing...")
    auto_billing_result = billing.setup_auto_billing(user_id)
    if auto_billing_result['success']:
        print(f"   ✓ {auto_billing_result['message']}")
        print(f"   Next charge: ${auto_billing_result['next_charge_amount']} "
              f"on {auto_billing_result['next_charge_date']}")

    # Process payment (mock)
    print("\n💰 Processing payment...")
    invoice = billing.generate_invoice(user_id)
    payment_result = billing.process_payment(
        user_id=user_id,
        amount=invoice.total,
        invoice_id=invoice.invoice_id
    )

    if payment_result['success']:
        print(f"   ✓ Payment successful!")
        print(f"   Transaction ID: {payment_result['transaction_id']}")
        print(f"   Amount: ${payment_result['amount']:.2f}")
        print(f"   Status: {payment_result['status'].upper()}")

    return payment_result


def run_all_examples():
    """Run all billing module examples"""
    print("\n" + "🚀"*30)
    print("BILLING MODULE COMPREHENSIVE EXAMPLES")
    print("🚀"*30)

    # Example 1: Subscription Management
    billing = example_1_subscription_management()

    # Example 2: LLM Usage Tracking
    billing = example_2_llm_usage_tracking(billing)

    # Example 3: Marketing API Tracking
    billing = example_3_marketing_api_tracking(billing)

    # Example 4: Invoice Generation
    invoice = example_4_invoice_generation(billing)

    # Example 5: Cost Estimation
    estimate = example_5_cost_estimation(billing)

    # Example 6: Billing Analytics
    summary = example_6_billing_analytics(billing)

    # Example 7: Payment Integration
    payment = example_7_payment_integration(billing)

    print("\n" + "✅"*30)
    print("ALL EXAMPLES COMPLETED SUCCESSFULLY!")
    print("✅"*30 + "\n")


if __name__ == "__main__":
    run_all_examples()