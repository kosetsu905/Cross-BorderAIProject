--- ecommerce_ai_agents/billing/invoice_generator.py (原始)


+++ ecommerce_ai_agents/billing/invoice_generator.py (修改后)
"""
Invoice Generator - Generates detailed invoices for billing periods

Features:
- Itemized billing breakdown
- Subscription fees
- LLM token usage charges
- Marketing API call charges
- Tax calculations
- Multiple currency support
"""

from typing import Dict, List, Optional
from dataclasses import dataclass
from datetime import date, datetime
import json

from .pricing_config import PricingConfig, SubscriptionPlan
from .usage_tracker import UsageTracker, UsageRecord


@dataclass
class InvoiceLineItem:
    """Single line item in an invoice"""
    description: str
    quantity: float
    unit_price: float
    total: float
    category: str  # 'subscription', 'llm_usage', 'api_calls', 'tax', 'discount'
    metadata: Optional[Dict] = None


@dataclass
class Invoice:
    """Complete invoice for a billing period"""
    invoice_id: str
    user_id: str
    period_start: date
    period_end: date
    generated_at: datetime
    currency: str
    line_items: List[InvoiceLineItem]
    subtotal: float
    tax_rate: float
    tax_amount: float
    discount: float
    total: float
    status: str = "pending"  # pending, paid, overdue, cancelled
    payment_due_date: Optional[date] = None

    def to_dict(self) -> Dict:
        """Convert invoice to dictionary"""
        return {
            "invoice_id": self.invoice_id,
            "user_id": self.user_id,
            "period_start": str(self.period_start),
            "period_end": str(self.period_end),
            "generated_at": self.generated_at.isoformat(),
            "currency": self.currency,
            "line_items": [
                {
                    "description": item.description,
                    "quantity": item.quantity,
                    "unit_price": item.unit_price,
                    "total": item.total,
                    "category": item.category,
                    "metadata": item.metadata
                }
                for item in self.line_items
            ],
            "subtotal": round(self.subtotal, 2),
            "tax_rate": self.tax_rate,
            "tax_amount": round(self.tax_amount, 2),
            "discount": round(self.discount, 2),
            "total": round(self.total, 2),
            "status": self.status,
            "payment_due_date": str(self.payment_due_date)
        }

    def to_json(self, indent: int = 2) -> str:
        """Convert invoice to JSON string"""
        return json.dumps(self.to_dict(), indent=indent)

    def format_summary(self) -> str:
        """Format invoice as human-readable summary"""
        lines = [
            "=" * 60,
            f"INVOICE {self.invoice_id}",
            "=" * 60,
            f"User ID: {self.user_id}",
            f"Billing Period: {self.period_start} to {self.period_end}",
            f"Generated: {self.generated_at.strftime('%Y-%m-%d %H:%M:%S')}",
            f"Currency: {self.currency}",
            f"Status: {self.status.upper()}",
            f"Payment Due: {self.payment_due_date}",
            "",
            "-" * 60,
            "LINE ITEMS",
            "-" * 60,
        ]

        for item in self.line_items:
            lines.append(
                f"{item.description:<35} "
                f"{item.quantity:>10} x {item.unit_price:>10.4f} = "
                f"{item.total:>10.2f}"
            )

        lines.extend([
            "-" * 60,
            f"{'Subtotal:':>48} {self.subtotal:>10.2f}",
            f"{'Tax (' + str(self.tax_rate * 100) + '%):':>48} {self.tax_amount:>10.2f}",
            f"{'Discount:':>48} -{self.discount:>9.2f}",
            "=" * 60,
            f"{'TOTAL DUE:':>48} {self.total:>10.2f} {self.currency}",
            "=" * 60,
        ])

        return "\n".join(lines)


class InvoiceGenerator:
    """
    Generate invoices based on usage records and pricing configuration

    Features:
    - Automatic calculation of all charges
    - Support for included credits in subscription plans
    - Tax and discount handling
    - Multiple output formats
    """

    def __init__(
        self,
        usage_tracker: UsageTracker,
        pricing_config: PricingConfig = None,
        default_tax_rate: float = 0.0,
        default_currency: str = "USD"
    ):
        self.usage_tracker = usage_tracker
        self.pricing_config = pricing_config or PricingConfig()
        self.default_tax_rate = default_tax_rate
        self.default_currency = default_currency
        self._invoice_counter = 0

    def _generate_invoice_id(self) -> str:
        """Generate unique invoice ID"""
        self._invoice_counter += 1
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        return f"INV-{timestamp}-{self._invoice_counter:04d}"

    def calculate_llm_charges(
        self,
        usage_record: UsageRecord,
        included_tokens: int = 0
    ) -> List[InvoiceLineItem]:
        """Calculate LLM token usage charges"""
        line_items = []

        # Aggregate by model
        aggregated = {}
        for usage in usage_record.token_usages:
            if usage.model_name not in aggregated:
                aggregated[usage.model_name] = {"input": 0, "output": 0}
            aggregated[usage.model_name]["input"] += usage.input_tokens
            aggregated[usage.model_name]["output"] += usage.output_tokens

        # Calculate charges per model
        total_used_tokens = 0
        for model_name, counts in aggregated.items():
            total_used_tokens += counts["input"] + counts["output"]

            pricing = self.pricing_config.get_llm_pricing(model_name)
            if not pricing:
                continue

            input_cost = pricing.calculate_cost(counts["input"], 0)
            output_cost = pricing.calculate_cost(0, counts["output"])
            total_cost = input_cost + output_cost

            if total_cost > 0:
                line_items.append(InvoiceLineItem(
                    description=f"LLM Usage - {model_name}",
                    quantity=counts["input"] + counts["output"],
                    unit_price=pricing.input_price_per_1k_tokens / 1000,
                    total=total_cost,
                    category="llm_usage",
                    metadata={
                        "input_tokens": counts["input"],
                        "output_tokens": counts["output"],
                        "input_cost": input_cost,
                        "output_cost": output_cost
                    }
                ))

        # Apply included tokens credit if applicable
        if included_tokens > 0 and total_used_tokens > 0:
            # Calculate average cost per token for credit application
            total_llm_cost = sum(item.total for item in line_items)
            if total_llm_cost > 0:
                credit_value = min(included_tokens, total_used_tokens) / total_used_tokens * total_llm_cost

                if credit_value > 0:
                    line_items.append(InvoiceLineItem(
                        description="Included Token Credits",
                        quantity=-included_tokens,
                        unit_price=0,
                        total=-credit_value,
                        category="discount",
                        metadata={"applied_credits": min(included_tokens, total_used_tokens)}
                    ))

        return line_items

    def calculate_api_charges(
        self,
        usage_record: UsageRecord,
        included_calls: int = 0
    ) -> List[InvoiceLineItem]:
        """Calculate marketing API call charges"""
        line_items = []

        # Aggregate by platform and call type
        aggregated = {}
        for call in usage_record.api_calls:
            key = (call.platform, call.call_type)
            if key not in aggregated:
                aggregated[key] = 0
            aggregated[key] += call.count

        # Calculate charges per platform
        total_calls = sum(
            count for (platform, call_type), count in aggregated.items()
            if call_type == "call"
        )

        for (platform, call_type), count in aggregated.items():
            pricing = self.pricing_config.get_marketing_api_pricing(platform)
            if not pricing:
                continue

            if call_type == "call":
                unit_price = pricing.price_per_call
                description = f"{platform.capitalize()} API Calls"
            elif call_type == "impression":
                unit_price = pricing.price_per_impression
                description = f"{platform.capitalize()} Impressions"
            elif call_type == "click":
                unit_price = pricing.price_per_click
                description = f"{platform.capitalize()} Clicks"
            else:
                continue

            total_cost = count * unit_price

            if total_cost > 0:
                line_items.append(InvoiceLineItem(
                    description=description,
                    quantity=count,
                    unit_price=unit_price,
                    total=total_cost,
                    category="api_calls",
                    metadata={"platform": platform, "call_type": call_type}
                ))

        # Apply included API calls credit if applicable
        if included_calls > 0 and total_calls > 0:
            # Calculate credit for basic API calls only
            call_items = [
                item for item in line_items
                if item.metadata and item.metadata.get("call_type") == "call"
            ]

            if call_items:
                total_call_cost = sum(item.total for item in call_items)
                credit_value = min(included_calls, total_calls) / total_calls * total_call_cost

                if credit_value > 0:
                    line_items.append(InvoiceLineItem(
                        description="Included API Call Credits",
                        quantity=-included_calls,
                        unit_price=0,
                        total=-credit_value,
                        category="discount",
                        metadata={"applied_credits": min(included_calls, total_calls)}
                    ))

        return line_items

    def generate_invoice(
        self,
        user_id: str,
        plan_id: str,
        period: Optional[str] = None,
        tax_rate: Optional[float] = None,
        discount: float = 0.0,
        currency: Optional[str] = None,
        payment_terms_days: int = 30
    ) -> Invoice:
        """
        Generate complete invoice for a user and billing period

        Args:
            user_id: User identifier
            plan_id: Subscription plan ID
            period: Billing period (YYYY-MM format), defaults to current month
            tax_rate: Tax rate (0.0-1.0), defaults to instance default
            discount: Fixed discount amount
            currency: Currency code, defaults to instance default
            payment_terms_days: Days until payment is due

        Returns:
            Complete Invoice object
        """
        # Get usage record
        usage_record = self.usage_tracker.get_user_usage(user_id, period)
        if not usage_record:
            # Create empty record if none exists
            from .usage_tracker import UsageRecord
            from datetime import timedelta
            now = datetime.now()
            period_key = now.strftime("%Y-%m")
            period_start = date(now.year, now.month, 1)
            if now.month == 12:
                period_end = date(now.year + 1, 1, 1) - timedelta(days=1)
            else:
                period_end = date(now.year, now.month + 1, 1) - timedelta(days=1)

            usage_record = UsageRecord(
                user_id=user_id,
                period_start=period_start,
                period_end=period_end
            )

        # Get subscription plan
        plan = self.pricing_config.get_subscription_plan(plan_id)
        if not plan:
            raise ValueError(f"Invalid plan ID: {plan_id}")

        # Determine currency
        currency = currency or plan.currency or self.default_currency

        # Determine tax rate
        tax_rate = tax_rate if tax_rate is not None else self.default_tax_rate

        # Build line items
        line_items = []

        # 1. Subscription fee
        if plan.monthly_fee > 0:
            line_items.append(InvoiceLineItem(
                description=f"{plan.plan_name} - Monthly Subscription",
                quantity=1,
                unit_price=plan.monthly_fee,
                total=plan.monthly_fee,
                category="subscription",
                metadata={"plan_id": plan_id, "plan_name": plan.plan_name}
            ))

        # 2. LLM usage charges (with included credits)
        llm_items = self.calculate_llm_charges(
            usage_record,
            plan.included_token_credits
        )
        line_items.extend(llm_items)

        # 3. API call charges (with included credits)
        api_items = self.calculate_api_charges(
            usage_record,
            plan.included_api_calls
        )
        line_items.extend(api_items)

        # Calculate subtotal
        subtotal = sum(item.total for item in line_items)

        # Calculate tax
        tax_amount = subtotal * tax_rate

        # Calculate total
        total = subtotal + tax_amount - discount

        # Generate invoice
        now = datetime.now()
        from datetime import timedelta
        due_date = date.today() + timedelta(days=payment_terms_days)

        invoice = Invoice(
            invoice_id=self._generate_invoice_id(),
            user_id=user_id,
            period_start=usage_record.period_start,
            period_end=usage_record.period_end,
            generated_at=now,
            currency=currency,
            line_items=line_items,
            subtotal=subtotal,
            tax_rate=tax_rate,
            tax_amount=tax_amount,
            discount=discount,
            total=max(0, total),  # Ensure non-negative
            status="pending",
            payment_due_date=due_date
        )

        return invoice

    def generate_estimate(
        self,
        user_id: str,
        plan_id: str,
        projected_token_usage: Dict[str, int],
        projected_api_calls: Dict[str, int],
        tax_rate: Optional[float] = None,
        currency: Optional[str] = None
    ) -> Invoice:
        """
        Generate cost estimate based on projected usage

        Args:
            user_id: User identifier
            plan_id: Subscription plan ID
            projected_token_usage: {model_name: token_count}
            projected_api_calls: {platform: call_count}
            tax_rate: Tax rate
            currency: Currency code

        Returns:
            Invoice object marked as estimate
        """
        # Get subscription plan
        plan = self.pricing_config.get_subscription_plan(plan_id)
        if not plan:
            raise ValueError(f"Invalid plan ID: {plan_id}")

        # Create mock usage record
        from .usage_tracker import UsageRecord, TokenUsage, MarketingAPICall
        from datetime import timedelta

        now = datetime.now()
        period_start = date(now.year, now.month, 1)
        if now.month == 12:
            period_end = date(now.year + 1, 1, 1) - timedelta(days=1)
        else:
            period_end = date(now.year, now.month + 1, 1) - timedelta(days=1)

        mock_record = UsageRecord(
            user_id=user_id,
            period_start=period_start,
            period_end=period_end
        )

        # Add mock token usages
        for model_name, tokens in projected_token_usage.items():
            # Assume 70% input, 30% output split
            input_tokens = int(tokens * 0.7)
            output_tokens = int(tokens * 0.3)
            mock_record.add_token_usage(model_name, input_tokens, output_tokens)

        # Add mock API calls
        for platform, count in projected_api_calls.items():
            mock_record.add_marketing_api_call(platform, "/api/v1/campaign", "call", count)

        # Generate invoice with mock data
        currency = currency or plan.currency or self.default_currency
        tax_rate = tax_rate if tax_rate is not None else self.default_tax_rate

        line_items = []

        # Subscription fee
        if plan.monthly_fee > 0:
            line_items.append(InvoiceLineItem(
                description=f"{plan.plan_name} - Monthly Subscription (Estimated)",
                quantity=1,
                unit_price=plan.monthly_fee,
                total=plan.monthly_fee,
                category="subscription",
                metadata={"plan_id": plan_id, "plan_name": plan.plan_name}
            ))

        # LLM usage
        llm_items = self.calculate_llm_charges(mock_record, plan.included_token_credits)
        line_items.extend(llm_items)

        # API calls
        api_items = self.calculate_api_charges(mock_record, plan.included_api_calls)
        line_items.extend(api_items)

        subtotal = sum(item.total for item in line_items)
        tax_amount = subtotal * tax_rate
        total = subtotal + tax_amount

        invoice = Invoice(
            invoice_id=f"EST-{self._generate_invoice_id()[4:]}",
            user_id=user_id,
            period_start=period_start,
            period_end=period_end,
            generated_at=now,
            currency=currency,
            line_items=line_items,
            subtotal=subtotal,
            tax_rate=tax_rate,
            tax_amount=tax_amount,
            discount=0.0,
            total=max(0, total),
            status="estimate",
            payment_due_date=period_end
        )

        return invoice